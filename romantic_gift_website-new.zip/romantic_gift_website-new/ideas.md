# Romantic Digital Gift Website - Design Approach

## Reference
This website is a **personalized romantic digital gift** created for a special occasion (anniversary/celebration). It features:
- Password-protected access (private/exclusive feel)
- Soft, warm romantic aesthetic with cream/beige and pink tones
- Floating hearts and romantic animations
- Background music player
- Anniversary countdown timer
- Photo timeline/memory gallery
- Mobile-first, single-column layout

---

## Chosen Design Philosophy: **"Intimate Scrapbook"**

### Design Movement
**Modern Romanticism** - Blending contemporary digital design with handcrafted, analog scrapbook aesthetics. Inspired by vintage love letters, pressed flowers, and personal journals, but executed with clean typography and smooth digital interactions.

### Core Principles
1. **Exclusivity & Privacy** - Password gate creates an intimate, private space
2. **Personal Storytelling** - Timeline and photos tell a unique love story
3. **Sensory Experience** - Music + visuals + animations create emotional resonance
4. **Handcrafted Feel** - Soft edges, organic shapes, and delicate details over corporate polish

### Color Philosophy
- **Primary Palette**: Cream (#F5F1ED), Soft Pink (#FFB3D9), Deep Rose (#D4517A), Warm Brown (#6B4423)
- **Emotional Intent**: Warmth, intimacy, nostalgia, and timeless romance
- **Reasoning**: Cream and soft pink evoke vintage love letters and rose petals; deep rose adds sophistication; warm brown grounds the design with earthiness

### Layout Paradigm
- **Mobile-first vertical scroll** - Single column, story-like progression
- **Asymmetric spacing** - Varied margins and padding create visual interest
- **Floating elements** - Hearts, photos, and text float naturally rather than grid-aligned
- **Organic shapes** - Soft borders, rounded corners, and curved dividers

### Signature Elements
1. **Floating Hearts** - Delicate hearts that drift upward throughout the page
2. **Wax Seal Envelope** - Password gate features a romantic envelope with red wax seal
3. **Soft Photo Frames** - Images have soft shadows and gentle blur effects, not rigid borders

### Interaction Philosophy
- **Gentle, unhurried** - Animations feel natural and organic, not snappy
- **Reward exploration** - Unlock reveals a beautiful experience; scrolling reveals memories gradually
- **Tactile feedback** - Buttons and interactions feel responsive but soft

### Animation Guidelines
- **Floating hearts**: Continuous, slow drift upward with opacity fade (3-5s duration)
- **Page transitions**: Smooth fade-in as sections come into view (400ms ease-out)
- **Button interactions**: Subtle scale (0.98) on press with 150ms ease-out
- **Countdown timer**: Numbers update smoothly without jarring jumps
- **Music player**: Slide in from bottom with 300ms ease-out

### Typography System
- **Display Font**: "Playfair Display" (serif) - for headings and romantic moments
- **Body Font**: "Poppins" (sans-serif) - clean, modern, readable
- **Accent Font**: "Dancing Script" (script) - for personal messages and quotes
- **Hierarchy**: Large serif for section titles, medium sans-serif for body, small script for personal notes

### Brand Essence
**One-liner**: *"A private digital scrapbook where every moment, photo, and memory of your love story is preserved and celebrated."*

**Personality**: Intimate, nostalgic, romantic, timeless

### Brand Voice
- **Headlines**: Poetic, personal, celebratory ("بدايتنا" - Our Beginning; "كل ثانية بتعدي وانت في قلبي" - Every second passes while you are in my heart)
- **CTAs**: Gentle, inviting ("Unlock the memories"; "Scroll to discover more")
- **Microcopy**: Warm, affectionate tone in Arabic and English

### Wordmark & Logo
A simple, elegant **heart symbol** (not a text logo) - minimalist, timeless, universally romantic. Rendered in deep rose (#D4517A) with subtle shadow.

### Signature Brand Color
**Deep Rose (#D4517A)** - The unmistakable romantic accent that appears in the wax seal, button highlights, and accent elements throughout.

---

## Implementation Notes
- Use Tailwind CSS with custom color tokens for the palette
- Implement floating hearts with CSS animations (@keyframes)
- Password protection via simple frontend validation
- Music player with play/pause, skip, and progress bar
- Countdown timer using JavaScript date calculations
- Photo gallery with soft shadows and hover effects
- Responsive design optimized for mobile viewing
