import { useState, useEffect } from 'react';
import { Heart } from 'lucide-react';

interface CountdownTimerProps {
  targetDate?: string; // Format: 'YYYY-MM-DD'
  label?: string;
  subtitle?: string;
}

interface TimeUnits {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export default function CountdownTimer({ 
  targetDate = '2026-06-01',
  label = 'بدايتنا',
  subtitle = 'كل ثانية بتعدي وأنتي في قلبي'
}: CountdownTimerProps) {
  const [time, setTime] = useState<TimeUnits>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const calculateTime = () => {
      const target = new Date(targetDate).getTime();
      const now = new Date().getTime();
      const difference = Math.abs(target - now);

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((difference / 1000 / 60) % 60);
      const seconds = Math.floor((difference / 1000) % 60);

      setTime({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);

    return () => clearInterval(interval);
  }, [targetDate]);

  const TimeUnit = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="bg-gradient-to-br from-secondary/40 to-secondary/20 rounded-lg p-4 min-w-20 mb-2 shadow-md hover:shadow-lg transition-shadow">
        <p className="font-display text-3xl font-bold text-primary">
          {String(value).padStart(2, '0')}
        </p>
      </div>
      <p className="text-sm text-foreground/60 font-medium">{label}</p>
    </div>
  );

  return (
    <section className="py-12 px-4 text-center">
      {/* Decorative hearts */}
      <div className="flex justify-center gap-2 mb-6">
        <Heart size={24} className="text-primary fill-primary animate-pulse" />
        <Heart size={24} className="text-primary fill-primary" />
        <Heart size={24} className="text-primary fill-primary animate-pulse" />
      </div>

      {/* Title */}
      <h2 className="font-display text-4xl md:text-5xl text-primary mb-2">
        {label}
      </h2>
      <p className="font-script text-lg text-foreground/70 mb-8">
        {subtitle}
      </p>

      {/* Timer */}
      <div className="flex justify-center gap-3 md:gap-6 flex-wrap mb-8">
        <TimeUnit value={time.days} label="يوم" />
        <TimeUnit value={time.hours} label="ساعة" />
        <TimeUnit value={time.minutes} label="دقيقة" />
        <TimeUnit value={time.seconds} label="ثانية" />
      </div>

      {/* Decorative divider */}
      <div className="flex items-center justify-center gap-3 mt-8">
        <div className="h-px bg-gradient-to-r from-transparent to-primary/30 flex-1 max-w-20" />
        <Heart size={16} className="text-primary/50" />
        <div className="h-px bg-gradient-to-l from-transparent to-primary/30 flex-1 max-w-20" />
      </div>
    </section>
  );
}
