import { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2 } from 'lucide-react';

interface MusicPlayerProps {
  songTitle?: string;
  songUrl?: string;
}

export default function MusicPlayer({ 
  songTitle = 'Bayen Habeet',
  songUrl = 'https://wnktcokbpgwgqtlvdsds.supabase.co/storage/v1/object/sign/Love/11._Bayen_Habeit.mp3?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV84NWJkYTg2MS1jODA3LTRlMjctOTgwMy0xNzAxMGQ1Mzc4ZDgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJMb3ZlLzExLl9CYXllbl9IYWJlaXQubXAzIiwic2NvcGUiOiJkb3dubG9hZCIsImlhdCI6MTc4Mzc5MzI1OSwiZXhwIjoyMDk5MTUzMjU5fQ.MxpN4TkZOST5t4d0rTWNheG6ZmFgRAmJ7mEwwN0RzFk'
}: MusicPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    const handleEnded = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('loadedmetadata', updateDuration);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const formatTime = (time: number) => {
    if (!time || isNaN(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <>
      <audio ref={audioRef} src={songUrl} crossOrigin="anonymous" />
      
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-primary to-primary/90 text-white shadow-2xl z-40 animate-slide-up">
        <div className="max-w-2xl mx-auto px-4 py-4">
          {/* Song title */}
          <div className="text-center mb-3">
            <p className="font-script text-lg">{songTitle}</p>
          </div>

          {/* Progress bar */}
          <div className="mb-3">
            <input
              type="range"
              min="0"
              max={duration || 0}
              value={currentTime}
              onChange={handleProgressChange}
              className="w-full h-1 bg-white/30 rounded-lg appearance-none cursor-pointer accent-white"
              style={{
                background: `linear-gradient(to right, white 0%, white ${duration ? (currentTime / duration) * 100 : 0}%, rgba(255,255,255,0.3) ${duration ? (currentTime / duration) * 100 : 0}%, rgba(255,255,255,0.3) 100%)`
              }}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4">
            <button className="hover:scale-110 transition-transform">
              <SkipBack size={20} />
            </button>

            <button
              onClick={togglePlay}
              className="bg-white text-primary p-3 rounded-full hover:scale-110 transition-transform shadow-lg"
            >
              {isPlaying ? <Pause size={24} /> : <Play size={24} className="ml-0.5" />}
            </button>

            <button className="hover:scale-110 transition-transform">
              <SkipForward size={20} />
            </button>

            {/* Volume control */}
            <div className="flex items-center gap-2 ml-auto">
              <Volume2 size={18} />
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-20 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer accent-white"
              />
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        .animate-slide-up {
          animation: slide-up 0.5s ease-out;
        }
      `}</style>
    </>
  );
}
