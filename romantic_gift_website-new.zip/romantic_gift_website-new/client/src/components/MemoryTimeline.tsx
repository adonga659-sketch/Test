import { Heart } from 'lucide-react';

interface Memory {
  date: string;
  title: string;
  description: string;
  image?: string;
}

interface MemoryTimelineProps {
  memories?: Memory[];
}

export default function MemoryTimeline({ 
  memories = [
    {
      date: '2026-06-26',
      title: 'أول يوم اتقابلنا فيه',
      description: 'من ساعتها وحياتي اتغيرت للأحسن',
      image: 'https://wnktcokbpgwgqtlvdsds.supabase.co/storage/v1/object/sign/Love/IMG_0179.jpeg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV84NWJkYTg2MS1jODA3LTRlMjctOTgwMy0xNzAxMGQ1Mzc4ZDgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJMb3ZlL0lNR18wMTc5LmpwZWciLCJzY29wZSI6ImRvd25sb2FkIiwiaWF0IjoxNzgzNzkwNTMwLCJleHAiOjIwOTkxNTA1MzB9.nr-IbFNc4--BKKGJIZ-eyAMa2t32pp7RyiVKcBob-30'
    },
    {
      date: '2026-06-01',
      title: 'قولتلك بحبك',
      description: 'اليوم الذي أخبرتك به عن شعوري الحقيقي',
      image: 'https://wnktcokbpgwgqtlvdsds.supabase.co/storage/v1/object/sign/Love/IMG_0162.jpeg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV84NWJkYTg2MS1jODA3LTRlMjctOTgwMy0xNzAxMGQ1Mzc4ZDgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJMb3ZlL0lNR18wMTYyLmpwZWciLCJzY29wZSI6ImRvd25sb2FkIiwiaWF0IjoxNzgzNzkyOTEzLCJleHAiOjIwOTkxNTI5MTN9.BbYiHxTCw4y7SiXURNL8IQlS28bw-HGEVtS6MWC2x18'
    },
    {
      date: '2026-06-26',
      title: 'لحظتنا الخاصة',
      description: 'اليوم ده عمري ما هنساه أبدا كنت ناسي الدنيا كلها وأنا معاكي',
      image: 'https://wnktcokbpgwgqtlvdsds.supabase.co/storage/v1/object/sign/Love/temp_image_8B931C6A-A2FD-4868-987D-099E7901636C.jpeg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV84NWJkYTg2MS1jODA3LTRlMjctOTgwMy0xNzAxMGQ1Mzc4ZDgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJMb3ZlL3RlbXBfaW1hZ2VfOEI5MzFDNkEtQTJGRC00ODY4LTk4N0QtMDk5RTc5MDE2MzZDLmpwZWciLCJzY29wZSI6ImRvd25sb2FkIiwiaWF0IjoxNzgzNzkyODE4LCJleHAiOjIwOTkxNTI4MTh9.jhs_NFPpAzoH6DhnEd6hJKgdOtZc68Hs5hGDzP5_1k4'
    },
    {
      date: '2026-07-07',
      title: 'أول فيديو كول لينا',
      description: 'مش هقدر انسي اليوم ده عشان بسببك وقعت ع ايدي ولسه وجعاني لدلوقتي 😂',
      image: 'https://wnktcokbpgwgqtlvdsds.supabase.co/storage/v1/object/sign/Love/IMG_0286.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV84NWJkYTg2MS1jODA3LTRlMjctOTgwMy0xNzAxMGQ1Mzc4ZDgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJMb3ZlL0lNR18wMjg2LnBuZyIsInNjb3BlIjoiZG93bmxvYWQiLCJpYXQiOjE3ODM3OTQxMTMsImV4cCI6MjA5OTE1NDExM30.UOc0la04GR4IMaBE4auz6sfSIb4kOpYk-uoD79sxr34'
    }
  ]
}: MemoryTimelineProps) {
  return (
    <section className="py-12 px-4">
      {/* Section title */}
      <div className="text-center mb-12">
        <h2 className="font-display text-4xl md:text-5xl text-primary mb-3">
          ذكرياتنا
        </h2>
        <p className="text-foreground/60 font-light">
          كل لحظة معك هي ذكرى أريد أن أحتفظ بها
        </p>
      </div>

      {/* Timeline */}
      <div className="max-w-2xl mx-auto">
        {memories.map((memory, index) => (
          <div key={index} className="mb-12 relative">
            {/* Timeline line */}
            {index !== memories.length - 1 && (
              <div className="absolute left-6 md:left-1/2 top-24 bottom-0 w-1 bg-gradient-to-b from-primary/60 to-primary/20" />
            )}

            {/* Timeline item */}
            <div className="flex gap-6 md:gap-0">
              {/* Left side - for desktop alternating */}
              <div className="hidden md:flex md:flex-1 md:justify-end md:pr-12">
                {index % 2 === 0 && memory.image && (
                  <div className="w-32 h-32 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                    <img 
                      src={memory.image} 
                      alt={memory.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                )}
              </div>

              {/* Center dot */}
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center shadow-lg z-10 relative">
                  <Heart size={24} className="text-white fill-white" />
                </div>
              </div>

              {/* Right side - content and image */}
              <div className="flex-1 md:pl-12">
                <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
                  {/* Date */}
                  <p className="text-sm text-primary/70 font-semibold mb-2">
                    {new Date(memory.date).toLocaleDateString('ar-EG', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>

                  {/* Title */}
                  <h3 className="font-display text-xl text-primary mb-2">
                    {memory.title}
                  </h3>

                  {/* Description */}
                  <p className="text-foreground/70 text-sm mb-4">
                    {memory.description}
                  </p>

                  {/* Image for mobile */}
                  {memory.image && (
                    <div className="md:hidden rounded-lg overflow-hidden">
                      <img 
                        src={memory.image} 
                        alt={memory.title}
                        className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                </div>

                {/* Image for desktop right side */}
                {index % 2 === 1 && memory.image && (
                  <div className="hidden md:block mt-4 w-32 h-32 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                    <img 
                      src={memory.image} 
                      alt={memory.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Call to action */}
      <div className="text-center mt-12 pt-8 border-t border-secondary/30">
        <p className="font-script text-lg text-foreground/70 mb-4">
          دعنا نملأ هذا الألبوم بذكريات أكثر جمالاً
        </p>
        <button className="bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 shadow-md hover:shadow-lg">
          بحبك أويييي❤
        </button>
      </div>
    </section>
  );
}
