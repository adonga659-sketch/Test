import { useState } from 'react';
import { Lock, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PasswordGateProps {
  onUnlock: () => void;
  secretWord?: string;
}

export default function PasswordGate({ onUnlock, secretWord = 'love' }: PasswordGateProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleUnlock = () => {
    setIsLoading(true);
    setError('');

    // Simulate a brief delay for effect
    setTimeout(() => {
      if (password.toLowerCase() === secretWord.toLowerCase()) {
        onUnlock();
      } else {
        setError('كلمة المرور غير صحيحة. حاول مرة أخرى.');
        setPassword('');
      }
      setIsLoading(false);
    }, 300);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleUnlock();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background px-4">
      {/* Floating hearts background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="absolute text-primary/20 animate-float"
            style={{
              left: `${20 + i * 15}%`,
              top: `${10 + i * 20}%`,
              animationDelay: `${i * 0.5}s`,
              fontSize: `${20 + i * 10}px`,
            }}
          >
            ♥
          </div>
        ))}
      </div>

      {/* Main content */}
      <div className="relative z-10 text-center max-w-md w-full">
        {/* Envelope illustration */}
        <div className="mb-12 flex justify-center">
          <div className="relative w-48 h-32 bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg shadow-2xl border-2 border-amber-200 flex items-center justify-center">
            {/* Envelope flap */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-amber-100 to-amber-50 rounded-t-lg border-b border-amber-200 transform -skew-y-6" />
            
            {/* Wax seal */}
            <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-16 h-16 bg-gradient-to-br from-red-600 to-red-800 rounded-full shadow-lg flex items-center justify-center border-2 border-red-900">
              <div className="text-white text-2xl font-bold">♥</div>
            </div>

            {/* Text on envelope */}
            <div className="text-center">
              <p className="font-display text-2xl text-primary mb-1">LOVE</p>
              <p className="font-script text-sm text-foreground/60">my everything</p>
            </div>
          </div>
        </div>

        {/* Title */}
        <h1 className="font-display text-4xl md:text-5xl text-primary mb-4">
          هديتي لكي
        </h1>
        <p className="text-foreground/70 mb-8 font-light">
          أدخل كلمة المرور لفتح هذه الهدية الخاصة
        </p>

        {/* Password input section */}
        <div className="space-y-4">
          <div className="flex items-center justify-center gap-2 mb-4 text-foreground/50">
            <Lock size={18} />
            <span className="text-sm">أدخل الكلمة السرية</span>
          </div>

          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="••••••••"
            className="w-full px-4 py-3 bg-white border-2 border-secondary/30 rounded-lg text-center font-poppins focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
            disabled={isLoading}
          />

          {error && (
            <p className="text-red-500 text-sm animate-pulse">{error}</p>
          )}

          <Button
            onClick={handleUnlock}
            disabled={isLoading || !password}
            className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-3 rounded-lg transition-all duration-300 flex items-center justify-center gap-2 group"
          >
            <Sparkles size={18} className="group-hover:animate-spin" />
            {isLoading ? 'جاري الفتح...' : 'فتح الهدية'}
            <Sparkles size={18} className="group-hover:animate-spin" />
          </Button>
        </div>

        {/* Hint */}
        <p className="text-foreground/40 text-xs mt-8 font-light">
          💡 تلميح: فكر في الشعور الذي تشعر به نحوي
        </p>
      </div>

      {/* Floating animation styles */}
      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) translateX(0px);
            opacity: 0;
          }
          10% {
            opacity: 0.8;
          }
          90% {
            opacity: 0.8;
          }
          100% {
            transform: translateY(-100vh) translateX(20px);
            opacity: 0;
          }
        }
        .animate-float {
          animation: float 6s ease-in infinite;
        }
      `}</style>
    </div>
  );
}
