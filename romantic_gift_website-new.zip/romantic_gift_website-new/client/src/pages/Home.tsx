import { useState } from 'react';
import PasswordGate from '@/components/PasswordGate';
import MusicPlayer from '@/components/MusicPlayer';
import CountdownTimer from '@/components/CountdownTimer';
import MemoryTimeline from '@/components/MemoryTimeline';

export default function Home() {
  const [isUnlocked, setIsUnlocked] = useState(false);

  if (!isUnlocked) {
    return <PasswordGate onUnlock={() => setIsUnlocked(true)} secretWord="love" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-secondary/10 to-background">
      {/* Background decoration */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {/* Floating hearts background */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute text-primary/5 text-6xl animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${8 + i}s`,
            }}
          >
            ♥
          </div>
        ))}
      </div>

      {/* Main content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="sticky top-0 bg-white/80 backdrop-blur-md shadow-sm z-20">
          <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663331631544/BqjXsc5veNxMCU7B88D9Gd/romantic-logo-QwvD5zwwZGqqtPsWFH43fL.webp"
                alt="Logo"
                className="w-8 h-8"
              />
              <h1 className="font-display text-2xl text-primary">هديتي لكي</h1>
            </div>
            <button 
              onClick={() => setIsUnlocked(false)}
              className="text-sm text-foreground/60 hover:text-foreground transition-colors"
            >
              تسجيل الخروج
            </button>
          </div>
        </header>

        {/* Hero section with background image */}
        <section className="relative h-96 md:h-[500px] overflow-hidden">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663331631544/BqjXsc5veNxMCU7B88D9Gd/hero-background-SuDSZMbmMEg4KQsZi3b7bU.webp)',
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
          
          {/* Hero content */}
          <div className="relative h-full flex flex-col items-center justify-center text-center px-4">
            <h2 className="font-display text-4xl md:text-6xl text-white drop-shadow-lg mb-4">
              هديتي الخاصة لكي
            </h2>
            <p className="font-script text-xl md:text-2xl text-white/90 drop-shadow-md max-w-2xl">
              ألبوم من الذكريات والحب والأحلام التي نشاركها معاً
            </p>
          </div>
        </section>

        {/* Introduction section */}
        <section className="max-w-4xl mx-auto px-4 py-12">
          <div className="bg-white rounded-lg shadow-md p-8 md:p-12">
            <p className="font-script text-lg md:text-xl text-foreground/80 leading-relaxed text-center mb-6">
              في كل لحظة أقضيها معك، أشعر بأن حياتي تصبح أكثر جمالاً وألواناً. هذا الألبوم هو مجموعة من أجمل اللحظات التي عشناها معاً، وكل ذكرى فيه تحكي قصة حبنا.
            </p>
            <p className="text-foreground/70 text-center">
              استمتع بالموسيقى، تصفح ذكرياتنا، وتذكر كل تلك اللحظات الخاصة التي جعلتك الشخص الأهم في حياتي.
            </p>
          </div>
        </section>

        {/* Countdown timer */}
        <CountdownTimer 
          targetDate="2026-06-01"
          label="بدايتنا"
          subtitle="كل ثانية بتعدي وانتي في قلبي"
        />

        {/* Divider */}
        <div className="max-w-4xl mx-auto px-4 py-8">
          <img 
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663331631544/BqjXsc5veNxMCU7B88D9Gd/floral-divider-YgSZFgJCgLAqzcXKu9yhov.webp"
            alt="Divider"
            className="w-full h-auto opacity-70"
          />
        </div>

        {/* Memory timeline */}
        <MemoryTimeline />

        {/* Closing section */}
        <section className="max-w-4xl mx-auto px-4 py-12">
          <div className="bg-gradient-to-r from-secondary/30 to-primary/10 rounded-lg p-8 md:p-12 text-center">
            <h3 className="font-display text-3xl text-primary mb-4">
              شكراً لك
            </h3>
            <p className="font-script text-lg text-foreground/80 mb-6">
              على كل اللحظات الجميلة التي نعيشها معاً
            </p>
            <p className="text-foreground/60 mb-8">
              هذا الألبوم سيستمر في النمو مع كل ذكرى جديدة. دعنا نملأه بحب أكثر وذكريات أجمل.
            </p>
            <button className="bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 shadow-md hover:shadow-lg">
              أضف ذكرى جديدة
            </button>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-white/50 backdrop-blur-sm border-t border-secondary/20 mt-12 py-8">
          <div className="max-w-4xl mx-auto px-4 text-center text-foreground/60 text-sm">
            <p>صُنعت بـ ❤️ لك</p>
            <p className="mt-2 text-xs">هذه الهدية خاصة بك وحدك</p>
          </div>
        </footer>
      </div>

      {/* Music player */}
      <MusicPlayer 
        songTitle="Bayen Habeet"
        songUrl="https://wnktcokbpgwgqtlvdsds.supabase.co/storage/v1/object/sign/Love/11._Bayen_Habeit.mp3?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV84NWJkYTg2MS1jODA3LTRlMjctOTgwMy0xNzAxMGQ1Mzc4ZDgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJMb3ZlLzExLl9CYXllbl9IYWJlaXQubXAzIiwic2NvcGUiOiJkb3dubG9hZCIsImlhdCI6MTc4Mzc5MzI1OSwiZXhwIjoyMDk5MTUzMjU5fQ.MxpN4TkZOST5t4d0rTWNheG6ZmFgRAmJ7mEwwN0RzFk"
      />

      {/* Floating animation styles */}
      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) translateX(0px) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 0.3;
          }
          90% {
            opacity: 0.3;
          }
          100% {
            transform: translateY(-100vh) translateX(50px) rotate(360deg);
            opacity: 0;
          }
        }
        .animate-float {
          animation: float 12s ease-in infinite;
        }
      `}</style>
    </div>
  );
}
